from flask import Flask
from resources.time_domain import ns_time_domain as ts
from flask_restplus import Api


api = Api(title='Diagnosis_box',
          version='1.0',
          description='This api is used in Diagnosis.',
          # All API metadatas
          )
api.add_namespace(ts, path='/tomain_domain')
# api.add_namespace(fft, path='/fft')
