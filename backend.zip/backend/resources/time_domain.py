
from flask_restplus import Namespace, Resource, fields
from flask import jsonify, request
import json
import os
from loguru import logger
from datetime import datetime


ns_time_domain = Namespace(
    'time_domain', description='Time domain feature of diagnosis box')


query_model = ns_time_domain.model('model', {
    'start_time': fields.DateTime(required=True, description='The starting time of query interval'),
    'end_time': fields.DateTime(required=True, description='The end time of query interval'),
    'columns': fields.List(fields.String, required=True),
    'axis': fields.String(required=False)
})


@ns_time_domain.route('/')
class TimeDomain(Resource):
    @ns_time_domain.doc(responses={200: 'ok', 400: 'Invalid arg', 500: ' Internal server error'})
    @ns_time_domain.expect(query_model, validate=True)
    def post(self):
        """
        Query the time domain features
        :return:
                200 if success;
                4XX if receive invalid argument;
                500 if occurs an internal server error. 
        """
        payload = request.json
        if isinstance(payload['columns'], list):
            tp = 'list'
        else:
            tp = 'not list'
        return jsonify({'type': tp})
        pass
